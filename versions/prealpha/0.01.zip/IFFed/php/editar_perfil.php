<?php
session_start();
include(__DIR__ . '/conexao.php');

// Verifica autenticação
if (!isset($_SESSION['nome_usuario']) || !isset($_SESSION['id'])) {
    header('Location: ../pages/login.php?erro=acesso_negado');
    exit;
}

$id = intval($_SESSION['id']);

// Recebe campos do formulário
$nome = isset($_POST['nome']) ? $conn->real_escape_string($_POST['nome']) : '';
$email = isset($_POST['email']) ? $conn->real_escape_string($_POST['email']) : '';
$data_nasc = isset($_POST['data_nasc']) && $_POST['data_nasc'] !== '' ? $conn->real_escape_string($_POST['data_nasc']) : NULL;
$bio = isset($_POST['bio']) ? $conn->real_escape_string($_POST['bio']) : '';

$foto_db = null;

// Tratamento de upload de foto (opcional)
if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
    $f = $_FILES['foto_perfil'];
    $tmp = $f['tmp_name'];
    $orig_name = basename($f['name']);
    $ext = strtolower(pathinfo($orig_name, PATHINFO_EXTENSION));
    $allowed = ['jpg','jpeg','png','gif','webp'];
    $check = @getimagesize($tmp);
    if ($check !== false && in_array($ext, $allowed)) {
        $new_name = time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
        $dest_dir = __DIR__ . '/../assets_front/img/uploads/';
        if (!is_dir($dest_dir)) mkdir($dest_dir, 0755, true);
        $dest = $dest_dir . $new_name;
        if (move_uploaded_file($tmp, $dest)) {
            // Armazenamos no DB apenas o caminho relativo usado pelo front: 'uploads/xxxxx.jpg'
            $foto_db = 'uploads/' . $new_name;
        }
    }
}

// Monta query de update
$sets = [];
if ($nome !== '') $sets[] = "nome = '$nome'";
if ($email !== '') $sets[] = "email = '$email'";
if ($data_nasc !== NULL) $sets[] = "data_nasc = '$data_nasc'";
else $sets[] = "data_nasc = NULL";
$sets[] = "bio = '$bio'";
if ($foto_db !== null) $sets[] = "foto = '$foto_db'";

if (count($sets) > 0) {
    $sql = "UPDATE perfil SET " . implode(', ', $sets) . " WHERE id = $id";
    $conn->query($sql);
}

// Redireciona de volta para o perfil com flag de sucesso
header('Location: ../pages/perfil.php?edit=ok');
exit;

?>
