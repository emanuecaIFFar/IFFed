<?php
session_start();
if(!isset($_SESSION['nome_usuario']) || !isset($_SESSION['id'])){
    header('Location: login.php?erro=acesso_negado');
    exit;
}
include('../php/conexao.php');

$id = intval($_SESSION['id']);
$sql = "SELECT * FROM perfil WHERE id = $id";
$res = $conn->query($sql);
$dados = $res ? $res->fetch_assoc() : [];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-gray-200 min-h-screen">
    <div class="max-w-3xl mx-auto p-6">
        <h1 class="text-2xl font-semibold mb-4">Editar Perfil</h1>

        <form action="../php/editar_perfil.php" method="POST" enctype="multipart/form-data" class="space-y-4">
            <div>
                <label class="block text-sm text-gray-400">Nome</label>
                <input name="nome" value="<?php echo htmlspecialchars($dados['nome'] ?? $_SESSION['nome_usuario']); ?>" class="w-full px-3 py-2 bg-[#111] border border-[#333] rounded" />
            </div>

            <div>
                <label class="block text-sm text-gray-400">E-mail</label>
                <input name="email" value="<?php echo htmlspecialchars($dados['email'] ?? ''); ?>" class="w-full px-3 py-2 bg-[#111] border border-[#333] rounded" />
            </div>

            <div>
                <label class="block text-sm text-gray-400">Data de Nascimento</label>
                <input type="date" name="data_nasc" value="<?php echo !empty($dados['data_nasc']) ? htmlspecialchars($dados['data_nasc']) : ''; ?>" class="w-full px-3 py-2 bg-[#111] border border-[#333] rounded" />
            </div>

            <div>
                <label class="block text-sm text-gray-400">Biografia</label>
                <textarea name="bio" rows="5" class="w-full px-3 py-2 bg-[#111] border border-[#333] rounded"><?php echo htmlspecialchars($dados['bio'] ?? ''); ?></textarea>
            </div>

            <div>
                <label class="block text-sm text-gray-400">Foto de Perfil (opcional)</label>
                <input type="file" name="foto_perfil" accept="image/*" class="mt-2" />
                <?php if (!empty($dados['foto'])): ?>
                    <div class="mt-3">
                        <img src="../assets_front/img/<?php echo htmlspecialchars($dados['foto']); ?>" alt="foto atual" width="120" style="border-radius:50%;" />
                    </div>
                <?php endif; ?>
            </div>

            <div class="flex gap-2">
                <a href="perfil.php" class="px-4 py-2 bg-gray-700 rounded">Cancelar</a>
                <button type="submit" class="px-4 py-2 bg-white text-black rounded font-semibold">Salvar</button>
            </div>
        </form>
    </div>
</body>
</html>
